import Post from './post/reducer.js'
import {combineReducers} from 'redux'
const rootReducer = combineReducers({
    Post
});

export default rootReducer;
