import React from 'react';

function ShowDetail() {
    return (
        <div className="loader center" style={{ marginTop: 300, width: '100%', alignSelf: 'center',marginInlineStart:'50%'}}>
                <i className="fa fa-spinner fa-spin fa-5x" />
        </div>
    );
}

export default ShowDetail;